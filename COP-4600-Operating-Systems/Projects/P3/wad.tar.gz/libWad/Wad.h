#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <string.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#define BUFF_SIZE 5000000	// 5 MB

using namespace std;

class Descriptors {
public:
	vector<struct Descriptors> subDir;
	int len;
	int off;
	string name;
};

class Wad {
public:
	static char buff[BUFF_SIZE];
	static vector<string> buff2;
	string magic;
	static vector<struct Descriptors> descElems;

	Wad();
	~Wad();
	static Wad* loadWad(const string& path);
	string getMagic();
	bool isContent(const string& path);
	bool isDirectory(const string& path);
	int getSize(const string& path);
	int getContents(const string& path, char* buffer, int length, int offset = 0);
	int getDirectory(const string& path, vector<string>* directory);
};

char Wad::buff[BUFF_SIZE];
vector<struct Descriptors> Wad::descElems = {};

bool fileErrCheck(ifstream& file);
void getDesBuffers(int descCount, int buffIndex);
int mapMarker(int j);
int nameSpaceMarker(struct Descriptors& desc, struct Descriptors& dirDesc, int size, int j);
int createFileStructure(struct Descriptors* cur, string end, int j);
struct Descriptors pathFinder(vector<string> elems, struct Descriptors& desc);
struct Descriptors parsePath(const string& path);
