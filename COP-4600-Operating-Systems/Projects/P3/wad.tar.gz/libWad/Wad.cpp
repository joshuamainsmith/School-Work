#include "Wad.h"

static Wad* wad = new Wad;

/// <summary>
/// The root directory is initialized once the Wad object is created.
/// The element is then inserted into the wad object vector
/// </summary>
/// <returns></returns>
Wad::Wad() 
{
	struct Descriptors root;
	root.name = "/";
	wad->descElems.emplace(wad->descElems.begin(), root);
}

/// <summary>
/// The wad object is deleted
/// </summary>
/// <returns></returns>
Wad::~Wad() 
{
	delete wad;
}

/// <summary>
/// The path is loaded into an ifstream object, starting at the end of the file.
/// The size is calculated, and some error checking occurs.
/// The file is then read into the wad object buffer for size pos.
/// Helper functions are then called to calculate the descriptor elements from the buffer
/// The file structure is then created, finding the map and namespace markers
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <returns>nullptr is returned upon success</returns>
Wad* Wad::loadWad(const string& path) 
{
	ifstream file(path, ios::binary | ios::ate);
	int pos = file.tellg();
	bool err = 0;

	err = fileErrCheck(file);

	if (err)
		return nullptr;

	file.seekg(0);

	err = fileErrCheck(file);

	if (err)
		return nullptr;

	file.read(wad->buff, pos);

	err = fileErrCheck(file);

	if (err)
		return nullptr;	

	getDesBuffers(0, 4);

	createFileStructure(&wad->descElems[0], "", 1);

	return nullptr;
}

/// <summary>
/// Magic is calculated in getDesBuffers
/// </summary>
/// <returns>magic string</returns>
string Wad::getMagic() 
{
	return wad->magic;
}

/// <summary>
/// isDirectory is called. If true, false is returned.
/// otherwise, file content is assumed.
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <returns>bool value</returns>
bool Wad::isContent(const string& path)
{
	return Wad::isDirectory(path) ? false : true;
}

/// <summary>
/// Root is checked first.
/// if getSize returns zero, that means it's a directory, so true should be returned.
/// Since zero is interpreted as false in C++, we need to return true in the else condition.
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <returns>true if root or if getSize() indicates directory</returns>
bool Wad::isDirectory(const string& path)
{
	if (path == "/")
		return true;

	return Wad::getSize(path) ? false : true;
}

/// <summary>
/// Parses through the path to get the descriptor element associated with path
/// A descriptor object is then initialized, then its length is returned.
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <returns>Length of descriptor object</returns>
int Wad::getSize(const string& path)
{
	struct Descriptors desc = parsePath(path);
	return desc.len;
}

/// <summary>
/// If path represents content, the element is found with
/// parsePath(). The offset is then calculated, and the 
/// wad object buffer is then copied in the buffer from 
/// the calculated offset for size length.
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <param name="buffer">buffer to contain contents from wad object buffer</param>
/// <param name="length">the size of the element</param>
/// <param name="offset">offset of the element</param>
/// <returns>length if content. -1 otherwise</returns>
int Wad::getContents(const string& path, char* buffer, int length, int offset)
{
	if (Wad::isContent(path))
	{
		struct Descriptors fPath = parsePath(path);

		int off = fPath.off + offset;

		memcpy(buffer, wad->buff + off, length);
		
		return length;
	}
	
	return -1;
}

/// <summary>
/// If directory, the sub directory of an element is found
/// it's name is then pushed onto the directory vector.
/// the number of directories is returned.
/// </summary>
/// <param name="path">path to WAD file data</param>
/// <param name="directory">vector where elements are pushed to</param>
/// <returns>number of elements</returns>
int Wad::getDirectory(const string& path, vector<string>* directory)
{
	if (Wad::isDirectory(path))
	{
		int i = 0;
		for (auto dir : parsePath(path).subDir) {
			directory->push_back(dir.name);
			i++;
		}

		return i;
	}

	return -1;
}

/// <summary>
/// File error checking from loadWad()
/// </summary>
/// <param name="file">passed in file object</param>
/// <returns>true if error, false otherwise</returns>
bool fileErrCheck(ifstream& file)
{
	if (file.fail() || file.bad() || file.eof())
	{
		if (file.fail())
		{
			cout << "Operation Failed - failbit set" << endl;
		}
		else if (file.bad())
		{
			cout << "Operation Failed - badbit set" << endl;
		}
		else if (file.eof())
		{
			cout << "Operation Failed - eofbit set" << endl;
		}

		cout << " Value of errno: " << errno << endl;
		cerr << strerror(errno) << endl;

		return true;
	}

	return false;
}

/// <summary>
/// Calculates the descriptor count and the descriptor offset.
/// Each descriptor at its offset then calculates the element offset, length, and name.
/// These attributes are then assigned to a descriptor object
/// The descriptor is then pushed onto a wad vector
/// </summary>
/// <param name="descCount">Descriptor count</param>
/// <param name="buffIndex">Descriptor offset</param>
void getDesBuffers(int descCount, int buffIndex)
{	
	char buffs[10];
	for (int i = 0; i < 4; i++)
	{
		buffs[i] = wad->buff[buffIndex];
		buffIndex++;
	}

	for (int i = 4; i < 8; i++)
	{
		buffs[i] = wad->buff[buffIndex];
		buffIndex++;
	}

	// Assign magic
	string m = wad->buff;
	wad->magic = m.substr(0, 4);

	buffIndex = 0;

	memcpy(&descCount, buffs, sizeof(descCount));
	memcpy(&buffIndex, &buffs[4], sizeof(buffIndex));

	int i = 0;
	while (i < descCount)
	{
		struct Descriptors descriptors;

		for (int i = 0; i < 4; i++)
		{
			buffs[i] = wad->buff[buffIndex];
			buffIndex++;
		}

		for (int i = 4; i < 8; i++)
		{
			buffs[i] = wad->buff[buffIndex];
			buffIndex++;
		}

		char elName[10];
		for (int i = 0; i < 8; i++)
		{
			elName[i] = wad->buff[buffIndex];
			buffIndex++;
		}
		memcpy(&descriptors.off, buffs, sizeof(descriptors.off));
		memcpy(&descriptors.len, &buffs[4], sizeof(descriptors.len));
		descriptors.name = elName;
		wad->descElems.push_back(descriptors);

		i++;
	}
}

/// <summary>
/// Elements are pushed onto wad vector
/// </summary>
/// <returns></returns>
int mapMarker(int j)
{
	int i = 0;
	while (i < 10)
	{
		wad->descElems[j].subDir.push_back(wad->descElems[j + i + 1]);
		i++;
	}

	return 0;
}

/// <summary>
/// Descriptor attributes are set and placed in the wad vector.
/// </summary>
/// <returns></returns>
int nameSpaceMarker(struct Descriptors &desc, struct Descriptors &dirDesc, int size, int j)
{
	int off = desc.off;
	int len = desc.len;

	wad->descElems.erase(wad->descElems.begin() + j);
	dirDesc.off = off;
	dirDesc.len = len;
	dirDesc.name = desc.name.substr(0, size - 6);

	wad->descElems.emplace(wad->descElems.begin() + j, dirDesc);

	return 0;
}

/// <summary>
/// Creates the map markers and namespace markers by
/// searching for key indicators, such as "_START" (namespace marker)
/// or "E#M#" (map marker)
/// the file structure is called recursively
/// pushing the elements onto a descriptor vector
/// </summary>
/// <param name="cur">current descriptor in recursive function</param>
/// <param name="end">Searching for end of map marker</param>
/// <param name="j">current iteration</param>
/// <returns>zero upon success</returns>
int createFileStructure(struct Descriptors* cur, string end, int j)
{
	for (; j < wad->descElems.size(); j++)
	{
		struct Descriptors desc = wad->descElems[j];

		if (desc.name == end) 
		{
			wad->descElems.erase(wad->descElems.begin() + j);
			return j;
		}

		else if (desc.name.size() > 6 && desc.name.substr(desc.name.size() - 6, desc.name.size()) == "_START")
		{
			struct Descriptors dirDesc;

			nameSpaceMarker(desc, dirDesc, desc.name.size(), j);

			cur->subDir.push_back(dirDesc);
			j = createFileStructure(&cur->subDir.back(), desc.name.substr(0, desc.name.size() - 6) + "_END", j + 1);
			j--;
		}

		else if (desc.name.size() == 4 && desc.name.at(0) == 'E' && desc.name.at(2) == 'M')
		{			
			mapMarker(j);
			cur->subDir.push_back(wad->descElems[j]);
			j += 10;
		}

		else
			cur->subDir.push_back(wad->descElems[j]);
	}
	return 0;
}

/// <summary>
/// Called by parsePath()
/// </summary>
struct Descriptors pathFinder(vector<string> elems, struct Descriptors &desc)
{
	for (auto sName : elems) {
		for (auto desc2 : desc.subDir) {
			if (desc2.name == sName) {
				desc = desc2;
				break;
			}
		}
	}

	return desc;
}

/// <summary>
/// Iterates through elements to find a match for a descriptor name in elements
/// Utilizes pathFinder
/// </summary>
struct Descriptors parsePath(const string& path)
{
	stringstream pStream(path.substr(1, path.length()));
	vector<string> elems;
	string elem = "";

	while (getline(pStream, elem, '/'))
		elems.push_back(elem);

	struct Descriptors desc = wad->descElems[0];

	return pathFinder(elems, desc);
}
