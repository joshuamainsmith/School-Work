#include <fuse.h>
#include "../libWad/Wad.cpp"

Wad* wadfs;
static int wad_getattr(const char* path, struct stat* stbuf) 
{
    struct Descriptors desc = parsePath(path);

    if (wadfs->isDirectory(path)) {
        vector<string> directory;
        stbuf->st_mode = S_IFDIR | 0555;
        stbuf->st_nlink = wadfs->getDirectory(path, &directory);
    }
    else {
        stbuf->st_mode = S_IFREG | 0444;
        stbuf->st_nlink = 1;
        stbuf->st_size = desc.len;
    }
    return 0;
}

static int wad_open(const char* path, struct fuse_file_info* fi) 
{
    if (wadfs->isContent(path)) {
        return 0;
    }
    return -1;
}

static int wad_read(const char* path, char* buf, size_t size, off_t offset, struct fuse_file_info* fi) 
{
    if (wadfs->isContent(path)) {
        return wadfs->getContents(path, buf, size, offset);
    }
    return -1;
}

static int wad_opendir(const char* path, struct fuse_file_info* fi) 
{
    return 0;
}

static int wad_readdir(const char* path, void* buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info* fi) 
{
    vector<string> getd;

    wadfs->getDirectory(path, &getd);

    for (auto entry : getd) {
        filler(buffer, entry.c_str(), 0, 0);
    }

    return 0;
}

struct fuse_operations ops = {
    .getattr = wad_getattr,
    .open = wad_open,
    .read = wad_read,
    .opendir = wad_opendir,
    .readdir = wad_readdir,
};

int main(int argc, char* argv[]) {
    if (argc < 2) {

        cout << "Usage: ./wadfs/wadfs somewadfile.wad /some/mount/directory" << endl;
        return -1;
    }

    int fArgc = argc;

    wadfs->loadWad(argv[1]);

    cout << wadfs->getMagic() << endl;

    char* fArgv[argc - 1];
    fArgv[0] = argv[0];
    fArgv[1] = argv[2];
    fArgv[2] = argv[3];

    fuse_main(fArgc - 1, fArgv, &ops, 0);

    return 0;
}
