#include "process_log.h"

/****************
Library Functions
*****************/

// Returns the process log level on success, and -1 otherwise.
int get_proc_log_level()
{
	return syscall(__x64_sys_getProcLog);
}

// Returns new_level on success, and -1 otherwise.
int set_proc_log_level(int new_level)
{
	return syscall(__x64_sys_setProcLog, new_level);
}

// Returns -1 for invalid log level, and level otherwise.
int proc_log_message(int level, char *message)
{
	return syscall(PROC_LOG_CALL, message, level);
}

/****************
Harness Functions
*****************/

// Returns an int array of 3 values. Used to make the set-process-log-level system call.
int*  retrieve_set_level_params(int new_level)
{
	int* arrSysCallTest = malloc(3);
	arrSysCallTest[0] = __x64_sys_setProcLog;       // System call number
	arrSysCallTest[1] = 1;                          // Number of parameters
	arrSysCallTest[2] = new_level;                  // New Log Level
	return arrSysCallTest;
}

// Returns an int array of 2 values. Used to make the get-process-log-level system call.
int* retrieve_get_level_params()
{
	int *arrSysCallTest = malloc(2);
	arrSysCallTest[0] = __x64_sys_getProcLog;   // System call number
	arrSysCallTest[1] = 0;                      // Number of parameters
	return arrSysCallTest;
}

// Returns set_proc_log_level's interpretation of the system call completing with return value ret_value.
int interpret_set_level_result(int ret_value)
{
	return ret_value;
}

// Returns get_proc_log_level's interpretation of the system call completing with return value ret_value.
int interpret_get_level_result(int ret_value)
{
	return ret_value;
}

// Returns proc_log_message's interpretation of the system call completing with return value ret_value.
int interpret_log_message_result(int ret_value)
{
	return ret_value;
}
