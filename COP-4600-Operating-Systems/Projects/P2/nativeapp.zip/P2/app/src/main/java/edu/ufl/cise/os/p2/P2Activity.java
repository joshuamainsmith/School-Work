package edu.ufl.cise.os.p2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class P2Activity extends Activity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private final View.OnClickListener myListener = new View.OnClickListener() {
        @SuppressLint("SetTextI18n")
        public void onClick(View v) {
            TextView displayBox = (TextView) findViewById(R.id.displayBox); //
            EditText filenameBox = (EditText) findViewById(R.id.filenameBox);

            String buff = stringFromJNI(filenameBox.getText().toString());

            if (buff != null) {
                displayBox.setText(buff);
            }
            else {
                displayBox.setText("Error: File Not Found");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2);

        Button submitButton = (Button)findViewById(R.id.submitButton);
        submitButton.setOnClickListener(myListener);
        final TextView contentsLabel = (TextView) findViewById(R.id.contentsLabel);

        // Example of a call to a native method
        /*TextView tv = (TextView) findViewById(R.id.displayBox);
        tv.setText(stringFromJNI());*/
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI(String filepath);
}
