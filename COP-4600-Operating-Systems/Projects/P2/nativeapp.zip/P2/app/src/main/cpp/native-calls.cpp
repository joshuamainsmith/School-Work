#include <jni.h>
#include <string>
#include "read_file.h"

extern "C"
JNIEXPORT jstring

JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(
        JNIEnv *env,
        jobject,
        jstring filepath) {
    /*std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());*/

    return env->NewStringUTF(read_file(env->GetStringUTFChars(filepath, 0)));

}
