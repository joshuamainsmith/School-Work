#include <cstdlib>
#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cerrno>
#include <cstring>
#include "unistd.h"
#include "read_file.h"

char *read_file(const char *filepath) {

	int fildes = open(filepath, O_RDONLY);

	if (fildes == -1) {
		printf("Error: %s\n", strerror(errno));
		return nullptr;
	}

	struct stat fileStat{};
	int intError = fstat(fildes, &fileStat);

	if (intError == -1) {
		printf("Error: %s\n", strerror(errno));
        return nullptr;
	}

	bool bDir = S_ISDIR(fileStat.st_mode);

	if (bDir) {
        printf("This is a directory - please select a file\n");
        return nullptr;
	}

	char *buf = (char *) malloc(fileStat.st_size + 1);

	buf[fileStat.st_size] = '\0';

	intError = read(fildes, buf, fileStat.st_size);

	if (intError == -1) {
		printf("Error: %s\n", strerror(errno));
        return nullptr;
	}

	intError = close(fildes);

	if (intError == -1) {
		printf("Error: %s\n", strerror(errno));
	}
	return buf;
}
