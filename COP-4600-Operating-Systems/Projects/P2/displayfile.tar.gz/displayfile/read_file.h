#pragma once
char *read_file(const char *filename);
