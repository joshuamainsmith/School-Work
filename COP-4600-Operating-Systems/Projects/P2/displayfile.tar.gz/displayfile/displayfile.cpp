#include <cstdio>
#include <cstdlib>
#include "read_file.h"

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf("Usage: displayfile [file]\n");
		return 1;
	}
	char *buff = read_file(argv[1]);

	if (buff == nullptr) {
		printf("Error: File Not Found\n");
		return 1;
	}

	printf("%s", buff);
	free(buff);

	return 0;
}
